import Link from "next/link"
import { Instagram, Music2 } from "lucide-react"
import Image from "next/image"

export function Footer() {
  const navItems = [
    { name: "HOME", href: "/" },
    { name: "ABOUT", href: "/about" },
    { name: "ARTISTS", href: "/artists" },
    { name: "DISTRIBUTION", href: "/distribution" },
    { name: "VIDEOS", href: "/videos" },
    { name: "NEWS", href: "/news" },
    { name: "GALLERY", href: "/gallery" },
  ]

  return (
    <footer className="w-full border-t border-border bg-background py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
          {/* Logo and Description */}
          <div>
            <Link href="/" className="inline-block mb-4">
              <Image src="/nexo-logo.png" alt="Nexo Music Distro" width={150} height={50} className="h-12 w-auto" />
            </Link>
            <p className="text-sm text-muted-foreground">
              Digital music distribution and entertainment for independent artists and labels.
            </p>
          </div>

          {/* Navigation */}
          <div>
            <h4 className="text-sm font-bold tracking-wide mb-4">NAVIGATION</h4>
            <div className="flex flex-col gap-2">
              {navItems.map((item) => (
                <Link
                  key={item.name}
                  href={item.href}
                  className="text-sm text-muted-foreground hover:text-accent transition-colors"
                >
                  {item.name}
                </Link>
              ))}
            </div>
          </div>

          {/* Social */}
          <div>
            <h4 className="text-sm font-bold tracking-wide mb-4">FOLLOW US</h4>
            <div className="flex gap-4">
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-muted-foreground hover:text-accent transition-colors"
              >
                <Instagram className="h-6 w-6" />
              </a>
              <a
                href="https://twitter.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-muted-foreground hover:text-accent transition-colors"
              >
                <Music2 className="h-6 w-6" />
              </a>
            </div>
            <div className="mt-4">
              <p className="text-sm text-muted-foreground">contact@nexomusicdistro.com</p>
            </div>
          </div>
        </div>

        <div className="border-t border-border pt-8">
          <p className="text-center text-sm text-muted-foreground">© 2025 Nexo Music Distro. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}

"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight, ChevronLeft, ChevronRight } from "lucide-react"

const slides = [
  {
    image: "/modern-music-studio-production-equipment-with-mixi.jpg",
    title: "DISTRIBUTE YOUR MUSIC WORLDWIDE",
    subtitle: "Reach 200+ Streaming Platforms",
    description: "Get your music on Spotify, Apple Music, Amazon, and 200+ more platforms with just one upload.",
    cta: "Start Distributing",
    link: "/distribution",
  },
  {
    image: "/streaming-music-distribution-digital-platforms-col.jpg",
    title: "MAXIMIZE YOUR ROYALTIES",
    subtitle: "Publishing Administration",
    description: "We collect all your publishing royalties from performance rights organizations worldwide.",
    cta: "Learn More",
    link: "/distribution",
  },
  {
    image: "/artist-talent-management-concert-performance-stage.jpg",
    title: "GROW YOUR CAREER",
    subtitle: "Talent Management Services",
    description: "Professional artist development, marketing, and brand partnerships to elevate your music career.",
    cta: "Join Our Roster",
    link: "/artists",
  },
  {
    image: "/music-publishing-royalties-analytics-charts-growth.jpg",
    title: "REAL-TIME ANALYTICS",
    subtitle: "Track Your Success",
    description: "Monitor your streams, earnings, and audience insights with our advanced analytics dashboard.",
    cta: "Get Started",
    link: "/distribution",
  },
  {
    image: "/global-music-network-world-map-with-glowing-connec.jpg",
    title: "GLOBAL REACH",
    subtitle: "Connect With The World",
    description: "Join thousands of independent artists who trust Nexo to distribute their music globally.",
    cta: "View Artists",
    link: "/artists",
  },
  {
    image: "/music-producer-at-work-creating-beats-in-modern-st.jpg",
    title: "YOUR MUSIC, YOUR RIGHTS",
    subtitle: "100% Ownership",
    description: "Keep all your rights and earn up to 100% of your royalties with our transparent payment system.",
    cta: "Contact Us",
    link: "/contact",
  },
]

export function HeroSlider() {
  const [currentSlide, setCurrentSlide] = useState(0)

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length)
    }, 4000)

    return () => clearInterval(timer)
  }, [])

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % slides.length)
  }

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length)
  }

  return (
    <div className="relative h-[600px] md:h-[700px] overflow-hidden">
      {slides.map((slide, index) => (
        <div
          key={index}
          className={`absolute inset-0 transition-opacity duration-1000 ${
            index === currentSlide ? "opacity-100 z-10" : "opacity-0 z-0"
          }`}
        >
          <Image
            src={slide.image || "/placeholder.svg"}
            alt={slide.title}
            fill
            className="object-cover"
            priority={index === 0}
          />
          <div className="absolute inset-0 bg-gradient-to-b from-background/50 via-background/80 to-background" />

          <div className="container relative z-20 mx-auto px-4 h-full flex items-center">
            <div className="max-w-4xl">
              <p className="text-sm tracking-[0.3em] text-accent mb-4 animate-fade-in">{slide.subtitle}</p>
              <h1 className="text-5xl md:text-7xl lg:text-8xl font-black tracking-tighter mb-6 text-balance animate-slide-up">
                # {slide.title}
              </h1>
              <p className="text-lg md:text-xl text-foreground/80 max-w-2xl mb-8 leading-relaxed animate-slide-up">
                {slide.description}
              </p>
              <div className="animate-slide-up">
                <Button
                  asChild
                  size="lg"
                  className="bg-accent text-accent-foreground hover:bg-accent/90 transition-all duration-300 hover:scale-105"
                >
                  <Link href={slide.link}>
                    {slide.cta} <ArrowRight className="ml-2 h-5 w-5" />
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </div>
      ))}

      {/* Navigation Buttons */}
      <button
        onClick={prevSlide}
        className="absolute left-4 top-1/2 -translate-y-1/2 z-30 bg-background/50 hover:bg-background/80 border border-border p-2 transition-all duration-300 hover:scale-110"
        aria-label="Previous slide"
      >
        <ChevronLeft className="h-6 w-6" />
      </button>
      <button
        onClick={nextSlide}
        className="absolute right-4 top-1/2 -translate-y-1/2 z-30 bg-background/50 hover:bg-background/80 border border-border p-2 transition-all duration-300 hover:scale-110"
        aria-label="Next slide"
      >
        <ChevronRight className="h-6 w-6" />
      </button>

      {/* Slide Indicators */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-30 flex gap-2">
        {slides.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentSlide(index)}
            className={`w-2 h-2 rounded-full transition-all duration-300 ${
              index === currentSlide ? "bg-accent w-8" : "bg-foreground/30 hover:bg-foreground/50"
            }`}
            aria-label={`Go to slide ${index + 1}`}
          />
        ))}
      </div>
    </div>
  )
}

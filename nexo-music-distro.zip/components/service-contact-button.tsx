"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"

interface ServiceContactButtonProps {
  service: string
}

export function ServiceContactButton({ service }: ServiceContactButtonProps) {
  return (
    <Button
      asChild
      className="mt-6 bg-accent text-accent-foreground hover:bg-accent/90 transition-all duration-300 hover:scale-105"
    >
      <Link href={`/contact?service=${encodeURIComponent(service)}`}>
        Get Started with This Service <ArrowRight className="ml-2 h-4 w-4" />
      </Link>
    </Button>
  )
}

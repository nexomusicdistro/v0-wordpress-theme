export function SectionDivider() {
  return (
    <div className="my-16 w-full overflow-hidden">
      <div className="text-border text-center tracking-wider">
        ————————————————————————————————————————————————————————————————————————————————
      </div>
    </div>
  )
}

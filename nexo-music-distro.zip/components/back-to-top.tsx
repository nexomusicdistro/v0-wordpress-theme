"use client"

import { ArrowUp } from "lucide-react"

export function BackToTop() {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  return (
    <button
      onClick={scrollToTop}
      className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-accent transition-colors group"
    >
      <span className="tracking-wide">Back to the top</span>
      <ArrowUp className="h-4 w-4 group-hover:-translate-y-1 transition-transform" />
    </button>
  )
}

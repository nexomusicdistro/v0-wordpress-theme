import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    const formData = await request.json()

    const YOUR_EMAIL = process.env.CONTACT_EMAIL || "info@nexomusicdistro.com"

    // Create email content
    const emailContent = `
New Contact Form Submission from Nexo Music Distro Website

Name: ${formData.name}
Email: ${formData.email}
Phone: ${formData.phone || "Not provided"}
Artist/Label Name: ${formData.artistName}
Service Interest: ${formData.service}

Message:
${formData.message}

---
Submitted at: ${new Date().toLocaleString()}
    `

    // In a production environment, you would integrate with an email service here
    // For example: SendGrid, Resend, Nodemailer, etc.
    // For now, we'll log it and return success
    console.log("[v0] Contact form submission:", emailContent)

    // TODO: Integrate with your email service provider
    // Example with Resend (you'd need to add this to your project):
    // const { Resend } = require('resend');
    // const resend = new Resend(process.env.RESEND_API_KEY);
    // await resend.emails.send({
    //   from: 'noreply@nexomusicdistro.com',
    //   to: YOUR_EMAIL,
    //   subject: `New Contact Form: ${formData.service}`,
    //   text: emailContent,
    // });

    return NextResponse.json({ success: true, message: "Form submitted successfully" })
  } catch (error) {
    console.error("[v0] Error processing form:", error)
    return NextResponse.json({ success: false, message: "Error submitting form" }, { status: 500 })
  }
}

import Image from "next/image"
import { SectionDivider } from "@/components/section-divider"
import { BackToTop } from "@/components/back-to-top"
import { ServiceContactButton } from "@/components/service-contact-button"
import { ScrollReveal } from "@/components/scroll-reveal"

export const metadata = {
  title: "Distribution Services - Nexo Music Distro",
  description:
    "Professional music distribution services for independent artists and labels. Distribute to 200+ platforms with real-time reporting and monthly payouts.",
}

export default function DistributionPage() {
  const artists = [
    "ARTIST ONE",
    "ARTIST TWO",
    "ARTIST THREE",
    "ARTIST FOUR",
    "ARTIST FIVE",
    "ARTIST SIX",
    "ARTIST SEVEN",
    "ARTIST EIGHT",
    "ARTIST NINE",
    "ARTIST TEN",
  ]

  return (
    <main className="min-h-screen">
      <ScrollReveal>
        <section className="relative overflow-hidden">
          <div className="absolute inset-0 z-0">
            <Image
              src="/music-distribution-concept-digital-streaming-platf.jpg"
              alt="Distribution Services"
              fill
              className="object-cover opacity-25"
              priority
            />
            <div className="absolute inset-0 bg-gradient-to-b from-background/60 via-background/90 to-background" />
          </div>

          <div className="container relative z-10 mx-auto px-4 py-16 md:py-24">
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-black tracking-tighter text-center mb-16 animate-fade-in">
              # Distribution – NEXO
            </h1>

            {/* Welcome Section */}
            <div className="max-w-4xl mx-auto text-center mb-24 animate-slide-up">
              <p className="text-xl md:text-2xl leading-relaxed text-foreground/90">
                Welcome to Nexo Distro the music distribution arm of Nexo focused on providing digital services for
                independent artists and labels
              </p>
            </div>
          </div>
        </section>
      </ScrollReveal>

      {/* Services */}
      <section className="container mx-auto px-4 py-8">
        <div className="max-w-5xl mx-auto space-y-16">
          {/* Music Distribution */}
          <ScrollReveal>
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div>
                <h2 className="text-3xl md:text-5xl font-black tracking-tight mb-6"># MUSIC DISTRIBUTION</h2>
                <p className="text-lg leading-relaxed text-foreground/80">
                  We distribute your music and videos to more than 200 streaming platforms globally and ensure you
                  receive all your earnings.
                </p>
                <ServiceContactButton service="Music Distribution" />
              </div>
              <div className="relative h-64 overflow-hidden border border-border group">
                <Image
                  src="/spotify-apple-music-tidal-streaming-platform-logos.jpg"
                  alt="Music Distribution"
                  fill
                  className="object-cover group-hover:scale-110 transition-transform duration-500"
                />
              </div>
            </div>
          </ScrollReveal>

          {/* Publishing Administration */}
          <ScrollReveal delay={100}>
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div className="relative h-64 overflow-hidden border border-border order-2 md:order-1 group">
                <Image
                  src="/music-publishing-contracts-royalties-legal-documen.jpg"
                  alt="Publishing Administration"
                  fill
                  className="object-cover group-hover:scale-110 transition-transform duration-500"
                />
              </div>
              <div className="order-1 md:order-2">
                <h2 className="text-3xl md:text-5xl font-black tracking-tight mb-6"># PUBLISHING ADMINISTRATION</h2>
                <p className="text-lg leading-relaxed text-foreground/80">
                  We manage, register, and license your compositions, as well as collect publishing royalties for your
                  music on your behalf.
                </p>
                <ServiceContactButton service="Publishing Administration" />
              </div>
            </div>
          </ScrollReveal>

          {/* Real-Time Reporting */}
          <ScrollReveal delay={200}>
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div>
                <h2 className="text-3xl md:text-5xl font-black tracking-tight mb-6"># REAL-TIME REPORTING</h2>
                <p className="text-lg leading-relaxed text-foreground/80">
                  Effortlessly and securely manage your music, revenue, and data with Nexo Distro.
                </p>
                <ServiceContactButton service="Real-Time Reporting" />
              </div>
              <div className="relative h-64 overflow-hidden border border-border group">
                <Image
                  src="/analytics-dashboard-real-time-data-graphs-charts-m.jpg"
                  alt="Real-Time Reporting"
                  fill
                  className="object-cover group-hover:scale-110 transition-transform duration-500"
                />
              </div>
            </div>
          </ScrollReveal>

          {/* Monthly Payouts */}
          <ScrollReveal delay={100}>
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div className="relative h-64 overflow-hidden border border-border order-2 md:order-1 group">
                <Image
                  src="/money-transfer-payment-banking-financial-earnings-.jpg"
                  alt="Monthly Payouts"
                  fill
                  className="object-cover group-hover:scale-110 transition-transform duration-500"
                />
              </div>
              <div className="order-1 md:order-2">
                <h2 className="text-3xl md:text-5xl font-black tracking-tight mb-6"># MONTHLY PAYOUTS</h2>
                <p className="text-lg leading-relaxed text-foreground/80">
                  Get your streaming revenue paid out directly to your bank account, EVERY MONTH!
                </p>
                <ServiceContactButton service="Monthly Payouts" />
              </div>
            </div>
          </ScrollReveal>

          {/* Direct Third Party Payments */}
          <ScrollReveal delay={200}>
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div>
                <h2 className="text-3xl md:text-5xl font-black tracking-tight mb-6"># DIRECT THIRD PARTY PAYMENTS</h2>
                <p className="text-lg leading-relaxed text-foreground/80">
                  We offer our clients the ability to split payment with any and all collaborators directly on our
                  platform.
                </p>
                <ServiceContactButton service="Direct Third Party Payments" />
              </div>
              <div className="relative h-64 overflow-hidden border border-border group">
                <Image
                  src="/collaboration-team-split-payments-revenue-sharing-.jpg"
                  alt="Third Party Payments"
                  fill
                  className="object-cover group-hover:scale-110 transition-transform duration-500"
                />
              </div>
            </div>
          </ScrollReveal>

          {/* Client Services */}
          <ScrollReveal delay={100}>
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div className="relative h-64 overflow-hidden border border-border order-2 md:order-1 group">
                <Image
                  src="/marketing-promotion-social-media-megaphone-adverti.jpg"
                  alt="Client Services"
                  fill
                  className="object-cover group-hover:scale-110 transition-transform duration-500"
                />
              </div>
              <div className="order-1 md:order-2">
                <h2 className="text-3xl md:text-5xl font-black tracking-tight mb-6"># CLIENT SERVICES</h2>
                <p className="text-lg leading-relaxed text-foreground/80">
                  We tap into unique marketing opportunities to propel our artists big and small into the spotlight,
                  drive sales, and better engage audiences.
                </p>
                <ServiceContactButton service="Client Services" />
              </div>
            </div>
          </ScrollReveal>

          {/* Playlisting */}
          <ScrollReveal delay={200}>
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div>
                <h2 className="text-3xl md:text-5xl font-black tracking-tight mb-6"># PLAYLISTING</h2>
                <p className="text-lg leading-relaxed text-foreground/80">
                  We make it simple for you to pitch your releases for expertly curated playlists and editorial
                  opportunities.
                </p>
                <ServiceContactButton service="Playlisting" />
              </div>
              <div className="relative h-64 overflow-hidden border border-border group">
                <Image
                  src="/spotify-playlist-curation-music-selection-editoria.jpg"
                  alt="Playlisting"
                  fill
                  className="object-cover group-hover:scale-110 transition-transform duration-500"
                />
              </div>
            </div>
          </ScrollReveal>

          {/* Brand & Media Partnerships */}
          <ScrollReveal delay={100}>
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div className="relative h-64 overflow-hidden border border-border order-2 md:order-1 group">
                <Image
                  src="/brand-partnerships-corporate-collaboration-busines.jpg"
                  alt="Brand Partnerships"
                  fill
                  className="object-cover group-hover:scale-110 transition-transform duration-500"
                />
              </div>
              <div className="order-1 md:order-2">
                <h2 className="text-3xl md:text-5xl font-black tracking-tight mb-6"># BRAND & MEDIA PARTNERSHIPS</h2>
                <p className="text-lg leading-relaxed text-foreground/80">
                  We work hands-on with leading brands, sports leagues, and professional and collegiate teams to bring
                  paid and promotional brand opportunities to the independent artists across our ecosystem.
                </p>
                <ServiceContactButton service="Brand & Media Partnerships" />
              </div>
            </div>
          </ScrollReveal>

          {/* YouTube Monetization */}
          <ScrollReveal delay={200}>
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div>
                <h2 className="text-3xl md:text-5xl font-black tracking-tight mb-6"># YOUTUBE MONETIZATION</h2>
                <p className="text-lg leading-relaxed text-foreground/80">
                  We manage channels for our clients to raise their Youtube channel revenue, Content ID revenue, bring
                  in potential ad revenue, and create official artist channels.
                </p>
                <ServiceContactButton service="YouTube Monetization" />
              </div>
              <div className="relative h-64 overflow-hidden border border-border group">
                <Image
                  src="/youtube-monetization-video-content-creator-analyti.jpg"
                  alt="YouTube Monetization"
                  fill
                  className="object-cover group-hover:scale-110 transition-transform duration-500"
                />
              </div>
            </div>
          </ScrollReveal>
        </div>
      </section>

      <SectionDivider />

      {/* Artists Section */}
      <ScrollReveal>
        <section className="container mx-auto px-4 py-16 pb-24">
          <div className="max-w-4xl mx-auto animate-fade-in">
            <p className="text-sm tracking-[0.3em] text-accent mb-8">/OUR ARTISTS/</p>

            <ul className="space-y-3">
              {artists.map((artist, index) => (
                <li
                  key={artist}
                  className="text-lg font-medium tracking-wide hover:text-accent transition-all duration-300 cursor-pointer hover:translate-x-2"
                  style={{ animationDelay: `${index * 0.1}s` }}
                >
                  • {artist}
                </li>
              ))}
            </ul>
          </div>
        </section>
      </ScrollReveal>

      {/* Back to Top */}
      <div className="container mx-auto px-4 pb-12 text-center">
        <BackToTop />
      </div>
    </main>
  )
}

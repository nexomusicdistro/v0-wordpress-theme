import { BackToTop } from "@/components/back-to-top"
import { Button } from "@/components/ui/button"
import { ScrollReveal } from "@/components/scroll-reveal"

export const metadata = {
  title: "News - Nexo Music Distro",
  description: "Latest news, announcements, and updates from Nexo Music Distribution.",
}

export default function NewsPage() {
  const newsItems = [
    {
      id: 1,
      date: "January 15, 2025",
      title: "Nexo Distro Reaches 10 Million Streams Milestone",
      excerpt:
        "Our distributed artists have collectively surpassed 10 million streams across all platforms. This incredible achievement showcases the talent and dedication of our roster.",
      category: "Milestone",
    },
    {
      id: 2,
      date: "January 8, 2025",
      title: "New Partnership with Major Playlist Curators",
      excerpt:
        "We're excited to announce our expanded playlisting opportunities for all Nexo artists. Our new partnerships will provide direct access to editorial playlists across multiple platforms.",
      category: "Announcement",
    },
    {
      id: 3,
      date: "December 20, 2024",
      title: "Year-End Report: 2024 in Review",
      excerpt:
        "Looking back at an incredible year of growth, new artist signings, and record-breaking streaming numbers. Read our comprehensive 2024 year-end report.",
      category: "Report",
    },
    {
      id: 4,
      date: "December 10, 2024",
      title: "Enhanced Analytics Dashboard Now Live",
      excerpt:
        "Our new real-time analytics dashboard offers deeper insights into your streaming data, audience demographics, and revenue tracking. Available now to all Nexo artists.",
      category: "Product Update",
    },
    {
      id: 5,
      date: "November 28, 2024",
      title: "Nexo Artists Featured in Major Brand Campaign",
      excerpt:
        "Three of our managed artists have been selected for a major national brand campaign, showcasing the power of our brand partnership program.",
      category: "News",
    },
    {
      id: 6,
      date: "November 15, 2024",
      title: "New Distribution Territories Added",
      excerpt:
        "We've expanded our distribution network to include 50 additional platforms and territories, giving our artists even greater global reach.",
      category: "Announcement",
    },
  ]

  return (
    <main className="min-h-screen">
      <ScrollReveal>
        <section className="container mx-auto px-4 py-16 md:py-24">
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-black tracking-tighter mb-16">NEWS – NEXO</h1>

          {/* News List */}
          <div className="max-w-4xl mx-auto space-y-8">
            {newsItems.map((item, index) => (
              <ScrollReveal key={item.id} delay={index * 100}>
                <article className="border-b border-border pb-8 last:border-0">
                  <div className="flex items-center gap-3 mb-3">
                    <span className="text-xs font-medium px-3 py-1 bg-muted text-foreground rounded-full tracking-wide">
                      {item.category}
                    </span>
                    <span className="text-sm text-muted-foreground">{item.date}</span>
                  </div>
                  <h2 className="text-2xl md:text-3xl font-bold mb-3 hover:text-accent transition-colors cursor-pointer">
                    {item.title}
                  </h2>
                  <p className="text-lg leading-relaxed text-foreground/80 mb-4">{item.excerpt}</p>
                  <button className="text-sm text-accent hover:underline">Read more →</button>
                </article>
              </ScrollReveal>
            ))}
          </div>

          {/* Load More */}
          <ScrollReveal delay={600}>
            <div className="max-w-4xl mx-auto mt-12 text-center">
              <Button variant="outline" size="lg">
                Load More
              </Button>
            </div>
          </ScrollReveal>
        </section>
      </ScrollReveal>

      {/* Back to Top */}
      <div className="container mx-auto px-4 pb-12 text-center">
        <BackToTop />
      </div>
    </main>
  )
}

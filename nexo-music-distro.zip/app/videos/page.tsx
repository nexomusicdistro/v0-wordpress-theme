import { BackToTop } from "@/components/back-to-top"
import { ScrollReveal } from "@/components/scroll-reveal"

export const metadata = {
  title: "Videos - Nexo Music Distro",
  description: "Watch music videos and content from Nexo artists.",
}

export default function VideosPage() {
  const videos = [
    {
      id: 1,
      title: 'Lyric James - "City Lights"',
      artist: "Lyric James",
      embedId: "dQw4w9WgXcQ", // Placeholder
    },
    {
      id: 2,
      title: 'Aurora Beats - "Electric Dreams"',
      artist: "Aurora Beats",
      embedId: "dQw4w9WgXcQ", // Placeholder
    },
    {
      id: 3,
      title: 'The Midnight Collective - "Stargazer"',
      artist: "The Midnight Collective",
      embedId: "dQw4w9WgXcQ", // Placeholder
    },
    {
      id: 4,
      title: 'Nova Symphony - "Resonance"',
      artist: "Nova Symphony",
      embedId: "dQw4w9WgXcQ", // Placeholder
    },
  ]

  return (
    <main className="min-h-screen">
      {/* Page Title */}
      <ScrollReveal>
        <section className="container mx-auto px-4 py-16 md:py-24">
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-black tracking-tighter mb-16">VIDEOS – NEXO</h1>

          {/* Videos Grid */}
          <div className="max-w-6xl mx-auto grid md:grid-cols-2 gap-8">
            {videos.map((video, index) => (
              <ScrollReveal key={video.id} delay={index * 100}>
                <div className="space-y-4">
                  <div className="aspect-video bg-muted border border-border overflow-hidden hover:scale-105 transition-transform duration-300">
                    <iframe
                      width="100%"
                      height="100%"
                      src={`https://www.youtube.com/embed/${video.embedId}`}
                      title={video.title}
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                      allowFullScreen
                      className="w-full h-full"
                    />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold mb-1">{video.title}</h3>
                    <p className="text-sm text-muted-foreground">{video.artist}</p>
                  </div>
                </div>
              </ScrollReveal>
            ))}
          </div>
        </section>
      </ScrollReveal>

      {/* Back to Top */}
      <div className="container mx-auto px-4 pb-12 text-center">
        <BackToTop />
      </div>
    </main>
  )
}

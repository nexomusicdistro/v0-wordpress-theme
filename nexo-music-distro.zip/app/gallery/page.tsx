import { BackToTop } from "@/components/back-to-top"
import Image from "next/image"
import { ScrollReveal } from "@/components/scroll-reveal"

export const metadata = {
  title: "Gallery - Nexo Music Distro",
  description: "Photos and visuals from Nexo artists, events, and releases.",
}

export default function GalleryPage() {
  const images = [
    {
      id: 1,
      title: "Studio Session - Lyric James",
      category: "Behind the Scenes",
      query: "recording studio session with artist at microphone",
    },
    {
      id: 2,
      title: "Aurora Beats - Album Cover",
      category: "Album Art",
      query: "abstract electronic music album cover with neon colors",
    },
    {
      id: 3,
      title: "Live Performance - The Midnight Collective",
      category: "Live",
      query: "live music performance on stage with lights",
    },
    {
      id: 4,
      title: "Nova Symphony - Press Photo",
      category: "Press",
      query: "professional musician portrait in urban setting",
    },
    {
      id: 5,
      title: "Nexo Events - Showcase Night",
      category: "Events",
      query: "music venue event with crowd and stage",
    },
    {
      id: 6,
      title: "Urban Echo - Music Video Still",
      category: "Music Video",
      query: "cinematic music video scene in city at night",
    },
    {
      id: 7,
      title: "Phoenix Fire - EP Artwork",
      category: "Album Art",
      query: "modern hip hop album cover design",
    },
    {
      id: 8,
      title: "Digital Dreams - Studio Setup",
      category: "Behind the Scenes",
      query: "professional music production studio with equipment",
    },
  ]

  return (
    <main className="min-h-screen">
      <ScrollReveal>
        <section className="container mx-auto px-4 py-16 md:py-24">
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-black tracking-tighter mb-16">GALLERY – NEXO</h1>

          <div className="max-w-7xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {images.map((image, index) => (
                <ScrollReveal key={image.id} delay={index * 50}>
                  <div className="group relative aspect-square overflow-hidden border border-border hover:border-accent transition-all duration-300 cursor-pointer hover:scale-105">
                    <Image
                      src={`/.jpg?height=600&width=600&query=${encodeURIComponent(image.query)}`}
                      alt={image.title}
                      fill
                      className="object-cover transition-transform duration-300 group-hover:scale-110"
                    />
                    <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-4">
                      <div>
                        <p className="text-xs text-accent mb-1">{image.category}</p>
                        <h3 className="text-lg font-bold">{image.title}</h3>
                      </div>
                    </div>
                  </div>
                </ScrollReveal>
              ))}
            </div>
          </div>
        </section>
      </ScrollReveal>

      <div className="container mx-auto px-4 pb-12 text-center">
        <BackToTop />
      </div>
    </main>
  )
}

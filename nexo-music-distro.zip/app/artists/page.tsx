import Image from "next/image"
import { SectionDivider } from "@/components/section-divider"
import { BackToTop } from "@/components/back-to-top"
import { ScrollReveal } from "@/components/scroll-reveal"

export const metadata = {
  title: "Artists - Nexo Music Distro",
  description: "Discover our roster of talented independent artists and labels under Nexo Music and Nexo Distro.",
}

export default function ArtistsPage() {
  const nexoMusicArtists = [
    "LYRIC JAMES",
    "AURORA BEATS",
    "THE MIDNIGHT COLLECTIVE",
    "NOVA SYMPHONY",
    "URBAN ECHO",
    "SKYLINE RECORDS",
    "PHOENIX FIRE",
    "DIGITAL DREAMS",
  ]

  const nexoDistroArtists = [
    "RHYTHM NATION",
    "SONIC WAVE",
    "CRYSTAL SOUND",
    "ECHO CHAMBER",
    "BASSLINE CREW",
    "HARMONY HOUSE",
    "PULSE MUSIC",
    "FREQUENCY ONE",
    "MELODIC MINDS",
    "BEAT ARCHITECTS",
    "SOUND EMPIRE",
    "GROOVE MECHANICS",
  ]

  return (
    <main className="min-h-screen">
      <ScrollReveal>
        <section className="relative overflow-hidden">
          <div className="absolute inset-0 z-0">
            <Image
              src="/music-artist-roster-performance-stage-lights-crowd.jpg"
              alt="Artists"
              fill
              className="object-cover opacity-25"
              priority
            />
            <div className="absolute inset-0 bg-gradient-to-b from-background/60 via-background/90 to-background" />
          </div>

          <div className="container relative z-10 mx-auto px-4 py-16 md:py-24">
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-black tracking-tighter mb-24">ARTISTS – NEXO</h1>

            <div className="grid md:grid-cols-3 gap-6 mb-24">
              <div className="relative h-64 overflow-hidden border border-border group">
                <Image
                  src="/musician-artist-performing-live-on-stage-with-spotli.jpg"
                  alt="Featured Artist"
                  fill
                  className="object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
              <div className="relative h-64 overflow-hidden border border-border group">
                <Image
                  src="/hip-hop-artist-rapper-in-recording-studio-with-mic.jpg"
                  alt="Featured Artist"
                  fill
                  className="object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
              <div className="relative h-64 overflow-hidden border border-border group">
                <Image
                  src="/dj-producer-performing-electronic-music-turntables.jpg"
                  alt="Featured Artist"
                  fill
                  className="object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
            </div>

            {/* Nexo Music Label Section */}
            <ScrollReveal>
              <div className="max-w-4xl mx-auto mb-24">
                <p className="text-sm tracking-[0.3em] text-accent mb-4">/NEXO MUSIC/</p>
                <h2 className="text-2xl md:text-4xl font-black mb-12 tracking-[0.2em]">
                  L A B E L / M A N A G E M E N T
                </h2>

                <ul className="space-y-3">
                  {nexoMusicArtists.map((artist) => (
                    <li
                      key={artist}
                      className="text-lg font-medium tracking-wide hover:text-accent transition-colors cursor-pointer"
                    >
                      • {artist}
                    </li>
                  ))}
                </ul>
              </div>
            </ScrollReveal>

            <SectionDivider />

            {/* Nexo Distro Section */}
            <ScrollReveal delay={200}>
              <div className="max-w-4xl mx-auto">
                <p className="text-sm tracking-[0.3em] text-accent mb-8">/NEXO DISTRO/</p>

                <ul className="space-y-3">
                  {nexoDistroArtists.map((artist) => (
                    <li
                      key={artist}
                      className="text-lg font-medium tracking-wide hover:text-accent transition-colors cursor-pointer"
                    >
                      • {artist}
                    </li>
                  ))}
                </ul>
              </div>
            </ScrollReveal>
          </div>
        </section>
      </ScrollReveal>

      {/* Back to Top */}
      <div className="container mx-auto px-4 pb-12 text-center">
        <BackToTop />
      </div>
    </main>
  )
}

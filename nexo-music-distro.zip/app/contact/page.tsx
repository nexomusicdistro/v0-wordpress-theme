"use client"

import type React from "react"

import { useState, useEffect, Suspense } from "react"
import { useSearchParams } from "next/navigation"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { SectionDivider } from "@/components/section-divider"
import { BackToTop } from "@/components/back-to-top"
import { ScrollReveal } from "@/components/scroll-reveal"
import { Music, Send, CheckCircle2 } from "lucide-react"

function ContactFormContent() {
  const searchParams = useSearchParams()
  const serviceFromUrl = searchParams.get("service")

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    service: serviceFromUrl || "",
    artistName: "",
    message: "",
  })
  const [isSubmitted, setIsSubmitted] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)

  useEffect(() => {
    if (serviceFromUrl) {
      setFormData((prev) => ({ ...prev, service: serviceFromUrl }))
    }
  }, [serviceFromUrl])

  const services = [
    "Music Distribution",
    "Publishing Administration",
    "Real-Time Reporting",
    "Monthly Payouts",
    "Direct Third Party Payments",
    "Client Services",
    "Playlisting",
    "Brand & Media Partnerships",
    "YouTube Monetization",
    "Other",
  ]

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      const response = await fetch("/api/send-email", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      })

      if (response.ok) {
        setIsSubmitted(true)
        setTimeout(() => {
          setIsSubmitted(false)
          setFormData({
            name: "",
            email: "",
            phone: "",
            service: "",
            artistName: "",
            message: "",
          })
        }, 5000)
      }
    } catch (error) {
      console.error("Error submitting form:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    })
  }

  return (
    <main className="min-h-screen">
      <ScrollReveal>
        <section className="relative overflow-hidden">
          <div className="absolute inset-0 z-0">
            <Image
              src="/music-studio-contact-form-professional-setup.jpg"
              alt="Contact Us"
              fill
              className="object-cover opacity-20"
              priority
            />
            <div className="absolute inset-0 bg-gradient-to-b from-background/70 via-background/90 to-background" />
          </div>

          <div className="container relative z-10 mx-auto px-4 py-16 md:py-24">
            <div className="max-w-4xl mx-auto text-center">
              <Music className="h-16 w-16 mx-auto mb-6 text-accent animate-pulse" />
              <h1 className="text-4xl md:text-6xl lg:text-7xl font-black tracking-tighter mb-6">
                # LET&apos;S WORK TOGETHER
              </h1>
              <p className="text-xl md:text-2xl text-muted-foreground leading-relaxed">
                Ready to take your music career to the next level? Fill out the form below and our team will get back to
                you within 24 hours.
              </p>
            </div>
          </div>
        </section>
      </ScrollReveal>

      <SectionDivider />

      <ScrollReveal>
        <section className="container mx-auto px-4 py-16">
          <div className="max-w-3xl mx-auto">
            {isSubmitted ? (
              <div className="text-center py-16">
                <CheckCircle2 className="h-20 w-20 text-accent mx-auto mb-6 animate-bounce" />
                <h2 className="text-3xl font-bold mb-4">Thank You!</h2>
                <p className="text-lg text-muted-foreground">
                  We&apos;ve received your message and will get back to you soon.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-8">
                <div className="border border-border p-8 hover:border-accent transition-all duration-300">
                  <h2 className="text-2xl font-bold mb-6 tracking-tight">Personal Information</h2>
                  <div className="space-y-6">
                    <div className="space-y-2">
                      <Label htmlFor="name" className="text-sm font-medium tracking-wide">
                        Full Name *
                      </Label>
                      <Input
                        id="name"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        required
                        className="bg-background/50 border-border focus:border-accent transition-all duration-300"
                        placeholder="John Doe"
                      />
                    </div>

                    <div className="grid md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <Label htmlFor="email" className="text-sm font-medium tracking-wide">
                          Email Address *
                        </Label>
                        <Input
                          id="email"
                          name="email"
                          type="email"
                          value={formData.email}
                          onChange={handleChange}
                          required
                          className="bg-background/50 border-border focus:border-accent transition-all duration-300"
                          placeholder="john@example.com"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="phone" className="text-sm font-medium tracking-wide">
                          Phone Number
                        </Label>
                        <Input
                          id="phone"
                          name="phone"
                          type="tel"
                          value={formData.phone}
                          onChange={handleChange}
                          className="bg-background/50 border-border focus:border-accent transition-all duration-300"
                          placeholder="+1 (555) 000-0000"
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="artistName" className="text-sm font-medium tracking-wide">
                        Artist/Label Name *
                      </Label>
                      <Input
                        id="artistName"
                        name="artistName"
                        value={formData.artistName}
                        onChange={handleChange}
                        required
                        className="bg-background/50 border-border focus:border-accent transition-all duration-300"
                        placeholder="Your Artist or Label Name"
                      />
                    </div>
                  </div>
                </div>

                <div className="border border-border p-8 hover:border-accent transition-all duration-300">
                  <h2 className="text-2xl font-bold mb-6 tracking-tight">Service Interest</h2>
                  <div className="space-y-2">
                    <Label htmlFor="service" className="text-sm font-medium tracking-wide">
                      Which service are you interested in? *
                    </Label>
                    <select
                      id="service"
                      name="service"
                      value={formData.service}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-2 bg-background border border-border rounded-md focus:border-accent focus:outline-none focus:ring-2 focus:ring-accent/20 transition-all duration-300"
                    >
                      <option value="">Select a service</option>
                      {services.map((service) => (
                        <option key={service} value={service}>
                          {service}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="border border-border p-8 hover:border-accent transition-all duration-300">
                  <h2 className="text-2xl font-bold mb-6 tracking-tight">Tell Us More</h2>
                  <div className="space-y-2">
                    <Label htmlFor="message" className="text-sm font-medium tracking-wide">
                      Message *
                    </Label>
                    <Textarea
                      id="message"
                      name="message"
                      value={formData.message}
                      onChange={handleChange}
                      required
                      rows={6}
                      className="bg-background/50 border-border focus:border-accent transition-all duration-300 resize-none"
                      placeholder="Tell us about your music, your goals, and what you're looking for from Nexo Distro..."
                    />
                    <p className="text-sm text-muted-foreground">
                      Please include details about your current distribution setup, monthly streams, and any specific
                      requirements.
                    </p>
                  </div>
                </div>

                <div className="flex justify-center">
                  <Button
                    type="submit"
                    size="lg"
                    disabled={isSubmitting}
                    className="bg-accent text-accent-foreground hover:bg-accent/90 transition-all duration-300 hover:scale-105 px-12"
                  >
                    <Send className="mr-2 h-5 w-5" />
                    {isSubmitting ? "Sending..." : "Submit Application"}
                  </Button>
                </div>
              </form>
            )}
          </div>
        </section>
      </ScrollReveal>

      <SectionDivider />

      <ScrollReveal>
        <section className="container mx-auto px-4 py-16 pb-24">
          <div className="max-w-4xl mx-auto">
            <div className="grid md:grid-cols-3 gap-8 text-center">
              <div className="p-6 border border-border hover:border-accent transition-all duration-300 hover:scale-105">
                <h3 className="font-bold mb-2 tracking-wide">Email</h3>
                <p className="text-sm text-muted-foreground">info@nexomusicdistro.com</p>
              </div>
              <div className="p-6 border border-border hover:border-accent transition-all duration-300 hover:scale-105">
                <h3 className="font-bold mb-2 tracking-wide">Response Time</h3>
                <p className="text-sm text-muted-foreground">Within 24 hours</p>
              </div>
              <div className="p-6 border border-border hover:border-accent transition-all duration-300 hover:scale-105">
                <h3 className="font-bold mb-2 tracking-wide">Support</h3>
                <p className="text-sm text-muted-foreground">24/7 Available</p>
              </div>
            </div>
          </div>
        </section>
      </ScrollReveal>

      <div className="container mx-auto px-4 pb-12 text-center">
        <BackToTop />
      </div>
    </main>
  )
}

export default function ContactPage() {
  return (
    <Suspense fallback={<div className="min-h-screen flex items-center justify-center">Loading...</div>}>
      <ContactFormContent />
    </Suspense>
  )
}

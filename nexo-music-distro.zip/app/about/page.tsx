import { SectionDivider } from "@/components/section-divider"
import { BackToTop } from "@/components/back-to-top"
import { ScrollReveal } from "@/components/scroll-reveal"

export const metadata = {
  title: "About Us - Nexo Music Distro",
  description:
    "Learn about Nexo Music Distribution - our story, mission, and commitment to independent artists and labels.",
}

export default function AboutPage() {
  return (
    <main className="min-h-screen">
      <ScrollReveal>
        <section className="container mx-auto px-4 py-16 md:py-24">
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-black tracking-tighter mb-24"># About Us – NEXO</h1>

          <div className="max-w-4xl mx-auto space-y-16">
            <ScrollReveal>
              <div>
                <p className="text-sm tracking-[0.3em] text-accent mb-8">/ABOUT US/</p>

                <h2 className="text-2xl md:text-4xl font-black mb-8">## WHO WE ARE</h2>

                <p className="text-lg leading-relaxed text-foreground/80 mb-6">
                  Founded in 2018, Nexo Music Distribution emerged from a vision to revolutionize the independent music
                  industry. What began as a small distribution service has evolved into a comprehensive entertainment
                  entity, focused on innovation and excellence in every aspect of music business.
                </p>

                <p className="text-lg leading-relaxed text-foreground/80 mb-6">
                  At Nexo, we believe that every independent artist deserves access to professional-grade distribution,
                  publishing administration, and career development tools. Our platform combines cutting-edge technology
                  with personalized service to ensure our artists receive the support they need to thrive in today's
                  competitive music landscape.
                </p>

                <p className="text-lg leading-relaxed text-foreground/80">
                  With over 500 artists distributed, 50 million streams across all platforms, and partnerships with
                  major playlists and brands, Nexo has established itself as a trusted partner for independent artists
                  and labels worldwide.
                </p>
              </div>
            </ScrollReveal>

            <SectionDivider />

            <ScrollReveal delay={200}>
              <div>
                <p className="text-sm tracking-[0.3em] text-accent mb-8">/OUR MISSION/</p>

                <p className="text-lg leading-relaxed text-foreground/80 mb-6">
                  Our commitment is to foster talent through innovation, providing independent artists with the
                  resources, guidance, and promotional support they need to succeed. We leverage advanced technology and
                  industry expertise to maximize revenue, expand reach, and build sustainable careers for our artists.
                </p>

                <p className="text-lg leading-relaxed text-foreground/80">
                  Through Nexo Distro and Nexo Music & Entertainment, we offer a complete ecosystem for music
                  distribution, publishing administration, label services, and talent management—all designed to help
                  independent artists compete at the highest level.
                </p>
              </div>
            </ScrollReveal>

            <SectionDivider />

            <ScrollReveal delay={400}>
              <div>
                <h2 className="text-2xl md:text-4xl font-black mb-8"># subsidiaries</h2>

                <div className="space-y-8">
                  <div>
                    <h3 className="text-xl font-bold mb-3 tracking-wide">NEXO DISTRO</h3>
                    <p className="text-lg leading-relaxed text-foreground/80">
                      Our flagship distribution service, providing independent artists and labels with access to 200+
                      streaming platforms, real-time analytics, monthly payouts, and comprehensive support services.
                    </p>
                  </div>

                  <div>
                    <h3 className="text-xl font-bold mb-3 tracking-wide">NEXO MUSIC & ENTERTAINMENT</h3>
                    <p className="text-lg leading-relaxed text-foreground/80">
                      Our label and management division, offering full-service artist development, marketing campaigns,
                      brand partnerships, and career guidance for our signed and managed roster.
                    </p>
                  </div>
                </div>
              </div>
            </ScrollReveal>
          </div>
        </section>
      </ScrollReveal>

      <div className="container mx-auto px-4 pb-12 text-center">
        <BackToTop />
      </div>
    </main>
  )
}

import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { SectionDivider } from "@/components/section-divider"
import { BackToTop } from "@/components/back-to-top"
import { HeroSlider } from "@/components/hero-slider"
import { ScrollReveal } from "@/components/scroll-reveal"
import { ArrowRight, Music, TrendingUp, Users } from "lucide-react"

export default function HomePage() {
  return (
    <main className="min-h-screen">
      <HeroSlider />

      <SectionDivider />

      <ScrollReveal>
        <section className="container mx-auto px-4 py-16">
          <div className="text-center mb-16">
            <p className="text-sm tracking-[0.3em] text-accent mb-4">/NEXO SERVICES/</p>
            <h2 className="text-3xl md:text-5xl font-bold tracking-tight">What We Offer</h2>
          </div>

          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            <div className="border border-border overflow-hidden hover:border-accent transition-all duration-300 group hover:scale-105">
              <div className="relative h-48 overflow-hidden">
                <Image
                  src="/streaming-music-distribution-digital-platforms-col.jpg"
                  alt="Music Distribution"
                  fill
                  className="object-cover group-hover:scale-110 transition-transform duration-500"
                />
              </div>
              <div className="p-8">
                <Music className="h-12 w-12 mb-4 text-accent transition-transform duration-300 group-hover:rotate-12" />
                <h3 className="text-xl font-bold mb-3 tracking-wide">MUSIC DISTRIBUTION</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Distribute your music to 200+ streaming platforms globally with real-time reporting and monthly
                  payouts.
                </p>
                <Link
                  href="/distribution"
                  className="inline-flex items-center gap-2 mt-4 text-sm text-accent hover:underline"
                >
                  Learn more <ArrowRight className="h-4 w-4" />
                </Link>
              </div>
            </div>

            <div className="border border-border overflow-hidden hover:border-accent transition-all duration-300 group hover:scale-105">
              <div className="relative h-48 overflow-hidden">
                <Image
                  src="/music-publishing-royalties-analytics-charts-growth.jpg"
                  alt="Publishing Admin"
                  fill
                  className="object-cover group-hover:scale-110 transition-transform duration-500"
                />
              </div>
              <div className="p-8">
                <TrendingUp className="h-12 w-12 mb-4 text-accent transition-transform duration-300 group-hover:rotate-12" />
                <h3 className="text-xl font-bold mb-3 tracking-wide">PUBLISHING ADMIN</h3>
                <p className="text-muted-foreground leading-relaxed">
                  We manage, register, and license your compositions, collecting all publishing royalties on your
                  behalf.
                </p>
                <Link
                  href="/distribution"
                  className="inline-flex items-center gap-2 mt-4 text-sm text-accent hover:underline"
                >
                  Learn more <ArrowRight className="h-4 w-4" />
                </Link>
              </div>
            </div>

            <div className="border border-border overflow-hidden hover:border-accent transition-all duration-300 group hover:scale-105">
              <div className="relative h-48 overflow-hidden">
                <Image
                  src="/artist-talent-management-concert-performance-stage.jpg"
                  alt="Talent Management"
                  fill
                  className="object-cover group-hover:scale-110 transition-transform duration-500"
                />
              </div>
              <div className="p-8">
                <Users className="h-12 w-12 mb-4 text-accent transition-transform duration-300 group-hover:rotate-12" />
                <h3 className="text-xl font-bold mb-3 tracking-wide">TALENT MANAGEMENT</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Comprehensive artist development, marketing, and brand partnerships to elevate your career.
                </p>
                <Link
                  href="/artists"
                  className="inline-flex items-center gap-2 mt-4 text-sm text-accent hover:underline"
                >
                  Learn more <ArrowRight className="h-4 w-4" />
                </Link>
              </div>
            </div>
          </div>
        </section>
      </ScrollReveal>

      <SectionDivider />

      <ScrollReveal>
        <section className="container mx-auto px-4 py-16">
          <div className="text-center mb-16">
            <p className="text-sm tracking-[0.3em] text-accent mb-4">/NEXO IMPACT/</p>
            <h2 className="text-3xl md:text-5xl font-bold tracking-tight">Our Reach</h2>
          </div>

          <div className="grid md:grid-cols-2 gap-8 max-w-6xl mx-auto mb-16">
            <div className="relative h-64 md:h-80 overflow-hidden border border-border group hover:scale-105 transition-transform duration-500">
              <Image
                src="/global-music-network-world-map-with-glowing-connec.jpg"
                alt="Global Reach"
                fill
                className="object-cover group-hover:scale-110 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background via-background/50 to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-8">
                <h3 className="text-2xl font-bold mb-2">200+ Platforms</h3>
                <p className="text-muted-foreground">Global distribution network</p>
              </div>
            </div>

            <div className="relative h-64 md:h-80 overflow-hidden border border-border group hover:scale-105 transition-transform duration-500">
              <Image
                src="/music-streaming-analytics-dashboard-with-rising-nu.jpg"
                alt="Analytics"
                fill
                className="object-cover group-hover:scale-110 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background via-background/50 to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-8">
                <h3 className="text-2xl font-bold mb-2">Real-Time Data</h3>
                <p className="text-muted-foreground">Track your success instantly</p>
              </div>
            </div>
          </div>
        </section>
      </ScrollReveal>

      <SectionDivider />

      <ScrollReveal>
        <section className="container mx-auto px-4 py-16">
          <div className="max-w-4xl mx-auto">
            <p className="text-sm tracking-[0.3em] text-accent mb-4">/LATEST NEWS/</p>
            <h2 className="text-3xl md:text-5xl font-bold tracking-tight mb-12">Stay Updated</h2>

            <div className="space-y-6">
              <div className="border-b border-border pb-6">
                <p className="text-sm text-muted-foreground mb-2">January 15, 2025</p>
                <h3 className="text-xl font-bold mb-2 hover:text-accent transition-colors cursor-pointer">
                  Nexo Distro Reaches 10 Million Streams Milestone
                </h3>
                <p className="text-muted-foreground leading-relaxed">
                  Our distributed artists have collectively surpassed 10 million streams across all platforms...
                </p>
              </div>

              <div className="border-b border-border pb-6">
                <p className="text-sm text-muted-foreground mb-2">January 8, 2025</p>
                <h3 className="text-xl font-bold mb-2 hover:text-accent transition-colors cursor-pointer">
                  New Partnership with Major Playlist Curators
                </h3>
                <p className="text-muted-foreground leading-relaxed">
                  We're excited to announce our expanded playlisting opportunities for all Nexo artists...
                </p>
              </div>
            </div>

            <div className="mt-8">
              <Button asChild variant="outline">
                <Link href="/news">View All News</Link>
              </Button>
            </div>
          </div>
        </section>
      </ScrollReveal>

      <SectionDivider />

      <ScrollReveal>
        <section className="relative overflow-hidden">
          <div className="absolute inset-0 z-0">
            <Image
              src="/music-producer-at-work-creating-beats-in-modern-st.jpg"
              alt="Get Started"
              fill
              className="object-cover opacity-20"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-background via-background/90 to-background/80" />
          </div>

          <div className="container relative z-10 mx-auto px-4 py-16 pb-24">
            <div className="max-w-3xl mx-auto text-center">
              <h2 className="text-3xl md:text-5xl font-bold tracking-tight mb-6">Ready to Distribute Your Music?</h2>
              <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
                Join hundreds of independent artists who trust Nexo Distro to manage their music distribution and
                maximize their revenue.
              </p>
              <Button
                asChild
                size="lg"
                className="bg-foreground text-background hover:bg-accent hover:text-accent-foreground"
              >
                <Link href="/distribution">
                  Start Distributing <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
            </div>
          </div>
        </section>
      </ScrollReveal>

      <div className="container mx-auto px-4 pb-12 text-center">
        <BackToTop />
      </div>
    </main>
  )
}

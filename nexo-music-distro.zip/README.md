# Nexo Music Distro Website

A modern, animated website for Nexo Music Distribution built with Next.js 16, featuring a professional dark theme and smooth scroll animations.

## Features

- **Auto-sliding Hero Section**: 6 dynamic slides showcasing services
- **Scroll Animations**: Beautiful animations triggered as users scroll
- **Contact Form Integration**: Forms send to your email via API
- **Responsive Design**: Mobile-first approach with Space Grotesk font
- **Dark Theme**: Professional music industry aesthetic

## Email Setup

To receive form submissions to your email:

1. Add your email to environment variables:
   - Go to your Vercel project settings
   - Add `CONTACT_EMAIL` with your email address

2. Integrate an email service (choose one):
   - **Resend** (recommended): Add `RESEND_API_KEY`
   - **SendGrid**: Add `SENDGRID_API_KEY`
   - **Nodemailer**: Configure SMTP settings

3. Update `/app/api/send-email/route.ts` with your chosen service

## Environment Variables

```env
CONTACT_EMAIL=your@email.com
RESEND_API_KEY=your_api_key_here
```

## Getting Started

```bash
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) to view the website.

## Pages

- **Home**: Hero slider with 6 animated slides
- **Distribution**: All services with contact forms
- **Artists**: Artist roster showcase
- **About**: Company information
- **Videos**: Video content gallery
- **News**: Latest updates
- **Gallery**: Photo gallery
- **Contact**: Main contact form

All pages feature scroll-triggered animations for an engaging user experience.
